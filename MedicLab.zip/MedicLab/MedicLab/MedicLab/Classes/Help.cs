using System;
using Avalonia.Controls;
using MedicLab.Data;

namespace MedicLab.Classes;

public static class Help
{
    public static ContentControl MainCC;
    public static Window MainWindow;
    public static TestContext DB = new TestContext();
}