﻿using System;
using System.Collections.Generic;

namespace MedicLab.Data;

public partial class Medlab
{
    public int Id { get; set; }

    public string Login { get; set; } = null!;

    public string Pass { get; set; } = null!;

    public string Fio { get; set; } = null!;

    public string Bday { get; set; } = null!;

    public string Serialpaswrdnum { get; set; } = null!;

    public string Telephone { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? Numstrah { get; set; }

    public string? Typestarh { get; set; }

    public string? Strahname { get; set; }

    public string Role { get; set; } = null!;
}
