using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace MedicLab.Rolesss;

public partial class Lab : UserControl
{
    public Lab()
    {
        InitializeComponent();
    }
}