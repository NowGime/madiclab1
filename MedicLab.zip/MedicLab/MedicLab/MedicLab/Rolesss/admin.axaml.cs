using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using MedicLab.Classes;
using Microsoft.EntityFrameworkCore;

namespace MedicLab.Rolesss;

public partial class admin : UserControl
{
    public admin()
    {
        InitializeComponent();
        LoadData();
    }

    public void LoadData()
    {
        Help.DB.Medlabs.Load();
    }
}