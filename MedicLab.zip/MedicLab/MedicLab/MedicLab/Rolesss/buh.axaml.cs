using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace MedicLab.Rolesss;

public partial class buh : UserControl
{
    public buh()
    {
        InitializeComponent();
    }
}