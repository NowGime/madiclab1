using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace MedicLab.Rolesss;

public partial class labi : UserControl
{
    public labi()
    {
        InitializeComponent();
    }
}