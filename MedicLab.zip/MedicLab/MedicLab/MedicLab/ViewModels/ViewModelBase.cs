﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace MedicLab.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}