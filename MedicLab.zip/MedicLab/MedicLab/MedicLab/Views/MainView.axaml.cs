using System.Linq;
using Avalonia.Controls;
using Avalonia.Interactivity;
using MedicLab.Classes;
using MedicLab.Data;
using MedicLab.Rolesss;
using Microsoft.EntityFrameworkCore;

namespace MedicLab.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }

    private void Enterbtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.DB.Medlabs.Load();
        var lb = Help.DB.Medlabs.FirstOrDefault(el => el.Login == LoginTb.Text && el.Pass == PassTb.Text && el.Role == "lab");
        if (lb != null)
        {
            Help.MainCC.Content = new Lab();
        }
        
        var lbi = Help.DB.Medlabs.FirstOrDefault(el => el.Login == LoginTb.Text && el.Pass == PassTb.Text && el.Role == "labi");
        if (lbi != null)
        {
            Help.MainCC.Content = new labi();
        }
        
        var bh = Help.DB.Medlabs.FirstOrDefault(el => el.Login == LoginTb.Text && el.Pass == PassTb.Text && el.Role == "buh");
        if (bh != null)
        {
            Help.MainCC.Content = new buh();
        }
        
        var adm = Help.DB.Medlabs.FirstOrDefault(el => el.Login == LoginTb.Text && el.Pass == PassTb.Text && el.Role == "admin");
        if (adm != null)
        {
            Help.MainCC.Content = new admin();
        }
    }
}