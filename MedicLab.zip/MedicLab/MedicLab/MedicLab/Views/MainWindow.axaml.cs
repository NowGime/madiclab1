using Avalonia.Controls;
using Avalonia.Interactivity;
using MedicLab.Classes;

namespace MedicLab.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.MainCC = MainCC;
        Help.MainCC.Content = new MainView();
    }

    private void Exit_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.MainCC.Content = new MainView();
    }
}